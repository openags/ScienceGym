"""Floating-base constrained motor controller with Inspire mimic dynamics.

This module consumes an internal robot-state estimate. The initial diagnostic
runner may use simulator proprioception; that does not qualify sensor isolation.
No contact wrench or base force is ever written into the simulator.
"""
import numpy as np
import mujoco
import osqp
from scipy import sparse
from scipy.spatial.transform import Rotation


class Balance:
    def __init__(self,m,d):
        self.m,self.d=m,d;self.qa=m.jnt_qposadr[m.actuator_trnid[:,0]];self.va=m.jnt_dofadr[m.actuator_trnid[:,0]]
        self.posture=d.qpos[self.qa].copy();self.feet=[m.site(s+'_sole').id for s in ['left','right']]
        self.foot_positions=[d.site_xpos[s].copy() for s in self.feet];self.foot_rotations=[d.site_xmat[s].reshape(3,3).copy() for s in self.feet]
        self.com_target=d.subtree_com[m.body('pelvis').id].copy();self.com_target[:2]=np.mean(self.foot_positions,axis=0)[:2]
        self.previous=None;self.max_iter=0;self.previous_comj=None
        self.eqj=[];self.eqdata=[]
        for i in range(m.neq):
            a,b=m.eq_obj1id[i],m.eq_obj2id[i];coef=m.eq_data[i,1]
            row=np.zeros(m.nv);row[m.jnt_dofadr[a]]=1;row[m.jnt_dofadr[b]]=-coef
            self.eqj.append(row);self.eqdata.append((m.jnt_qposadr[a],m.jnt_qposadr[b],coef,m.eq_data[i,0]))
        self.eqj=np.array(self.eqj)
        self.unactuated=np.array([i for i in range(m.nv) if i not in set(self.va)])

    def jacobian(self,point,body):
        jp,jr=np.zeros((3,self.m.nv)),np.zeros((3,self.m.nv));dp,dr=np.zeros_like(jp),np.zeros_like(jr)
        mujoco.mj_jac(self.m,self.d,jp,jr,point,body);mujoco.mj_jacDot(self.m,self.d,dp,dr,point,body)
        return np.vstack([jp,jr]),np.vstack([dp,dr])

    def torque(self,targets=None,posture=None,dt=.01,forces=None):
        m,d=self.m,self.d;n=m.nv;k=len(self.eqj);total=n+12+k
        mass=np.zeros((n,n));mujoco.mj_fullM(m,d,mass);bias=d.qfrc_bias-d.qfrc_passive
        js=[];acc=[]
        for i,site in enumerate(self.feet):
            j,dj=self.jacobian(d.site_xpos[site],int(m.site_bodyid[site]));js.append(j)
            error=np.r_[self.foot_positions[i]-d.site_xpos[site],Rotation.from_matrix(self.foot_rotations[i]@d.site_xmat[site].reshape(3,3).T).as_rotvec()]
            acc.append(180*error-27*j@d.qvel-dj@d.qvel)
        jf=np.vstack(js);dynamics=np.c_[mass,-jf.T,-self.eqj.T]
        def pad(j):return np.c_[j,np.zeros((len(j),12+k))]
        posture=self.posture if posture is None else posture
        rows=[pad(np.eye(n)[self.va])];ys=[45*(posture-d.qpos[self.qa])-13*d.qvel[self.va]]
        cj=np.zeros((3,n));mujoco.mj_jacSubtreeCom(m,d,cj,m.body('pelvis').id)
        cd=np.zeros(3) if self.previous_comj is None else (cj-self.previous_comj)@d.qvel/dt;self.previous_comj=cj.copy()
        rows.append(12*pad(cj));ys.append(12*(70*(self.com_target-d.subtree_com[m.body('pelvis').id])-18*cj@d.qvel-cd))
        pj,pdj=self.jacobian(d.body('pelvis').xpos,m.body('pelvis').id)
        upright=Rotation.from_matrix(d.body('pelvis').xmat.reshape(3,3).T).as_rotvec()
        rows.append(8*pad(pj[3:]));ys.append(8*(60*upright-16*pj[3:]@d.qvel-pdj[3:]@d.qvel))
        for side,ref in (targets or {}).items():
            site=m.site(side+'_wrist_reference').id;j,dj=self.jacobian(d.site_xpos[site],int(m.site_bodyid[site]))
            error=np.asarray(ref)-d.site_xpos[site];rows.append(60*pad(j[:3]));ys.append(60*(100*error-22*j[:3]@d.qvel-dj[:3]@d.qvel))
            if hasattr(self,'palm_rotations'):
                rotation_error=Rotation.from_matrix(self.palm_rotations[side]@d.site_xmat[site].reshape(3,3).T).as_rotvec()
                rows.append(30*pad(j[3:]));ys.append(30*(60*rotation_error-16*j[3:]@d.qvel-dj[3:]@d.qvel))
        rows.append(np.c_[np.zeros((12+k,n)),np.eye(12+k)*.0005]);ys.append(np.zeros(12+k))
        cost=np.vstack(rows);desired=np.concatenate(ys);P=cost.T@cost+np.eye(total)*1e-6;q=-cost.T@desired
        eqerr=np.array([d.qpos[a]-c*d.qpos[b]-offset for a,b,c,offset in self.eqdata])
        eqacc=-300*eqerr-35*self.eqj@d.qvel
        A=[dynamics[self.unactuated],pad(jf),pad(self.eqj),dynamics[self.va]]
        lo=[-bias[self.unactuated],np.concatenate(acc),eqacc,m.actuator_ctrlrange[:,0]-bias[self.va]]
        hi=[-bias[self.unactuated],np.concatenate(acc),eqacc,m.actuator_ctrlrange[:,1]-bias[self.va]]
        wr=[];wl=[];wh=[]
        for foot in range(2):
            off=n+foot*6;row=np.zeros(total);row[off+2]=1;wr.append(row);wl.append(5);wh.append(800)
            for axis,mu in [(0,.6),(1,.6),(3,.025),(4,.07),(5,.012)]:
                for sign in [-1,1]:
                    row=np.zeros(total);row[off+axis]=sign;row[off+2]=-mu;wr.append(row);wl.append(-np.inf);wh.append(0)
        A.append(np.array(wr));lo.append(wl);hi.append(wh)
        solver=osqp.OSQP();solver.setup(P=sparse.csc_matrix(np.triu(P)),q=q,A=sparse.csc_matrix(np.vstack(A)),l=np.concatenate(lo),u=np.concatenate(hi),verbose=False,eps_abs=2e-5,eps_rel=2e-5,max_iter=6000,polishing=True)
        if self.previous is not None:solver.warm_start(x=self.previous)
        result=solver.solve(raise_error=False)
        if result.info.status_val not in (1,2):raise RuntimeError('Balance QP: '+result.info.status)
        self.previous=result.x;self.max_iter=max(self.max_iter,result.info.iter)
        torque=dynamics[self.va]@result.x+bias[self.va]
        for side,force in (forces or {}).items():
            site=m.site(side+'_wrist_reference').id;j,_=self.jacobian(d.site_xpos[site],int(m.site_bodyid[site]))
            torque+=j[:3,self.va].T@np.asarray(force)
        return np.clip(torque,m.actuator_ctrlrange[:,0],m.actuator_ctrlrange[:,1])
